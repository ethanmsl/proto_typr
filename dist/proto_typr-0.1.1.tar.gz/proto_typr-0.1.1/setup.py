# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['proto_typr']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.28.2,<3.0.0', 'typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['proto-typr = proto_typr.commands:app']}

setup_kwargs = {
    'name': 'proto-typr',
    'version': '0.1.1',
    'description': '',
    'long_description': '# proto_typr\nTest Repo for use with [Typer CLI framework](https://typer.tiangolo.com/)\n\n~~While `pytest` works fine `coverage` is having issues parsing the mapping of functions to tests.~~\n~~Additional work needed on setting up tests and testing harness appropriate to the framework.~~\n\nTesting working correctly with multiple adjustments and switch to `pytest-cov`, which uses `coverage`, but more easily integrates with `pytest`.\n\n\n',
    'author': 'Ethan Skowronski-Lutz',
    'author_email': '33399972+ethanmsl@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
