"""
Landing page for repo assuming only the `proto_typer/` (inclusive) sub tree is
documented

.. include:: ../../README.md
"""
