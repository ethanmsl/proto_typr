"""
Program entery point.
"""

from proto_typr import commands

commands.app()
