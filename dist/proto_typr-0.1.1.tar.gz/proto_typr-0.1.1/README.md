# proto_typr
Test Repo for use with [Typer CLI framework](https://typer.tiangolo.com/)

~~While `pytest` works fine `coverage` is having issues parsing the mapping of functions to tests.~~
~~Additional work needed on setting up tests and testing harness appropriate to the framework.~~

Testing working correctly with multiple adjustments and switch to `pytest-cov`, which uses `coverage`, but more easily integrates with `pytest`.


