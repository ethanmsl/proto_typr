![tests_badge](https://github.com/ethanmsl/proto_typr/actions/workflows/test-poet.yml/badge.svg)

[link to GitHub Pages hosting Pdoc generated site...?](https://ethanmsl.github.io/proto_typr/)

# proto_typr
Test Repo for use with [Typer CLI framework](https://typer.tiangolo.com/).   
(Mostly just '**scratch paper**' coding to check/explore behavior of framework.)


Example with `proto-typr` installed locally from wheel:
<img width="769" alt="proto-typr installed example" src="https://user-images.githubusercontent.com/33399972/215660485-a74087e1-0201-426e-8ecb-d42409a4b92d.png">



~~While `pytest` works fine `coverage` is having issues parsing the mapping of functions to tests.~~
~~Additional work needed on setting up tests and testing harness appropriate to the framework.~~

Testing working correctly with multiple adjustments and switch to `pytest-cov`, which uses `coverage`, but more easily integrates with `pytest`.


