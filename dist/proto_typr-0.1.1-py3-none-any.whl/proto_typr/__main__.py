"""
__main__
"""
from proto_typr import commands

commands.app()
